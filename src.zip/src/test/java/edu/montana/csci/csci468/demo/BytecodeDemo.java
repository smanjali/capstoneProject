package edu.montana.csci.csci468.demo;

import java.util.Objects;

public class BytecodeDemo {

//    int add(int i) {
//        return i + 13;
//    }

    public static void main(String[] args) {
        Objects.equals(null, null);
    }

}
